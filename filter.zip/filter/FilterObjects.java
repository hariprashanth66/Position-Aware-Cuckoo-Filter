package filter;

public class FilterObjects {

	 char[] fingerprint;
	 int size;
	
	public  FilterObjects()
	{
		fingerprint = new char[5];
		size =0;
	}
}
