package filter;

public class ScaleUpFilterObjects {

}
