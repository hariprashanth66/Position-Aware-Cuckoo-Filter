package filter;

	


	import java.io.BufferedReader;
	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.UnsupportedEncodingException;
	import java.math.BigInteger;
	import java.security.MessageDigest;
	import java.security.NoSuchAlgorithmException;
	import java.time.Clock;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Map;
	import java.util.concurrent.TimeUnit;

	public class PositionAwareFilter {


		private final Integer Max_Kicks = 50;
		private int filterSize = 1750;
		PosAwareFilterObjects filter[];
		int insertedCount;
		int successCount;
		int failureCount;
		String hashAlgorithm = "MD5";
		Map<Integer, ArrayList<Long>> routeMap;
		ArrayList<Long> routeIp;
		private int lookupNum;
		

		public PositionAwareFilter() {
			filter = new PosAwareFilterObjects[filterSize];

			routeMap = new HashMap<Integer, ArrayList<Long>>();
			for (int i = 0; i < filterSize; i++)
				filter[i] = new PosAwareFilterObjects();

			insertedCount = 0;
			successCount = 0;
			failureCount = 0;
			lookupNum = 0;
		}

		public long convertIptoDecimal(String ip) {
			long prefix = 0;

			// 256 is the base of ip addr. So, 256^3, 256^2,..256^0 is performed on
			// ip addr.

			String[] ipArr = ip.split("\\.");
			for (int i = 0; i < ipArr.length; i++) {
				int pow = 3 - i;

				int pre = Integer.parseInt(ipArr[i]);

				prefix += (pre * Math.pow(256, pow));

			}

			return prefix;
		}

		private String calculateHash(String prefix, String algorithm) {
			MessageDigest digest;
			try {
				digest = MessageDigest.getInstance(algorithm);

				byte[] hashedBytes = digest.digest(prefix.getBytes("UTF-8"));
				return convertByteArrtoString(hashedBytes);

			} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;

		}

		private String convertByteArrtoString(byte[] hashedVal) {

			StringBuilder build = new StringBuilder();
			for (int i = 0; i < hashedVal.length; i++) {
				build.append(Integer.toString((hashedVal[i] & 0xff) + 0x100, 16).substring(1));
			}
			return build.toString();

		}

		private char generateFingerprint(long prefix) {
			String hashStr = calculateHash(String.valueOf(prefix), hashAlgorithm);

			BigInteger val = new BigInteger(hashStr, 16);
			int mappedValue = val.intValue();
			mappedValue = (mappedValue & 0xFF) % 127;
			char fp = (char) mappedValue;
			return fp;

		}

		private int calculatePosition(String prefix, String algorithm) {
			String hash = calculateHash((prefix), algorithm);

			BigInteger val = new BigInteger(hash, 16);
			int mappedValue = val.intValue();

			mappedValue = mappedValue % filterSize;
			if (mappedValue < 0) {
				mappedValue = mappedValue * -1;
			}
			return mappedValue;

		}

		private boolean isInsertSucess(char fp, int pos, int hashPosition) {

			if((filter[pos].size > ((int)(filter[pos].fingerprint[5])%48)) || filter[pos].size>5)
				return false;
			
			else if(hashPosition==1)
			{
				filter[pos].fingerprint[filter[pos].size] = fp;

				filter[pos].size +=1;
				
			} else if(hashPosition==2)
			{
				int insertPos = (int)(filter[pos].fingerprint[5])%48;
				filter[pos].fingerprint[insertPos] = fp;
				insertPos = insertPos-1;
				filter[pos].fingerprint[5] = convertIntToChar(insertPos);
				
				
			}
			
			return true;
			
		}

		private char convertIntToChar(int val)
		{
			return Integer.toString(val).charAt(0);
		}
		
		private boolean insertItem(char fp, int pos1, int pos2) {
			if (isInsertSucess(fp, pos1,1))
				return true;
			if (isInsertSucess(fp, pos2, 2))
				return true;

			int pos = pos1;

			for (int i = 0; i < Max_Kicks; i++) {
				
				int toInsertPos = filter[pos].size;
				toInsertPos = toInsertPos -1;
				
				char tmpFp = filter[pos].fingerprint[toInsertPos];

				filter[pos].fingerprint[toInsertPos] = fp;
				
				toInsertPos = toInsertPos +1;

				
				filter[pos].fingerprint[5] = convertIntToChar(toInsertPos);

				int nextPos = (calculatePosition(tmpFp + "", hashAlgorithm)) ^ pos;

				nextPos = nextPos % filterSize;

				if (isInsertSucess(tmpFp, nextPos,2))
					return true;

			}

			System.out.println("Max Kicks reached");
			return false;

		}

		private boolean insertToLacf(char fp, int pos1, int pos2) {
			if (insertItem(fp, pos1, pos2)) {
				insertedCount++;
				return true;
			}

			return false;

		}

		private void insertIntoFilter(long prefix, int preLength) {
			char fingerprint = generateFingerprint(prefix);

			// System.out.println(fingerprint);

			int pos1 = -1, pos2 = -1;

			pos1 = calculatePosition(String.valueOf(prefix), hashAlgorithm);
			pos2 = (calculatePosition(fingerprint + "", hashAlgorithm)) ^ pos1; // calculating
																				// pos2
																				// by
																				// XOR.

			pos2 = pos2 % filterSize;

			// find popularity of the prefix length

			
			insertToLacf(fingerprint, pos1, pos2);

		}

		

		private void insertIntoMap(long prefix, int preLen) {

			if (!(routeMap.containsKey(preLen))) {
				routeIp = new ArrayList<Long>();
				routeIp.add(prefix);
				routeMap.put(preLen, routeIp);
			} else
				routeMap.get(preLen).add(prefix);

			insertIntoFilter(prefix, preLen);

		}

		public void insertInputFile(String name) throws IOException {
			BufferedReader buf = new BufferedReader(new FileReader(new File(name)));
			String line = null;
			while ((line = buf.readLine()) != null) {

				String ip[] = line.split("/");
				long prefix = convertIptoDecimal(ip[0]);
				int preLength = Integer.parseInt(ip[1]);
				// System.out.println(prefix);
				prefix = prefix >> (32 - preLength);
				// System.out.println(prefix);

				insertIntoMap(prefix, preLength);

			}

		}

		private boolean isIpFound(char fp, int pos , int hashPosition) {

			if(hashPosition ==1)
			{
				
				int end = filter[pos].size;
			
			for (int i = 0; i < end; i++) {
				lookupNum++;
				if (filter[pos].fingerprint[i] == fp)
					return true;
						
			}}
			else
			{
				int start = (int)(filter[pos].fingerprint[5])%48;
				
				for (int i = start+1; i < 5; i++) {
					lookupNum++;
					if (filter[pos].fingerprint[i] == fp)
						return true;
			}
			}
			return false;

		}

		private boolean searchInFilter(int prelen, long prefix) {
			int pos1 = -1;
			int pos2 = -1;

			char fp = generateFingerprint(prefix);
			pos1 = calculatePosition(String.valueOf(prefix), hashAlgorithm);

			pos2 = (calculatePosition(fp + "", hashAlgorithm)) ^ pos1;

			pos2 = pos2 % filterSize;

			if (isIpFound(fp, pos1 , 1))
				return true;

			if (isIpFound(fp, pos2 , 2))
				return true;

			return false;
		}

		private boolean search(long prefix) {

			long ip = prefix;

			for (int preLength = 32; preLength >= 1; preLength--) {

				if (searchInFilter(preLength, ip)) {
					if (routeMap.get(preLength) != null) {
						if (routeMap.get(preLength).contains(ip))
						{}
						return true;
					}
					
				}
				ip = ip >> 1;
			}
			return false;

		}
		List<String> failureList = new ArrayList<String>();

		private void lookup(String file) throws IOException {

			BufferedReader buf = new BufferedReader(new FileReader(new File(file)));

			ArrayList<String> lookupList = new ArrayList<String>();
			String line = null;
			while ((line = buf.readLine()) != null) {
				line.replaceAll("\n", "");
				lookupList.add(line);
			}
			long start = System.nanoTime();

			for (String i : lookupList) {
				Long prefix = convertIptoDecimal(i);

				if (search(prefix))
					successCount++;
				else
				{
					failureList.add(i);

			
					failureCount++;
				}

			}
			long stop = System.nanoTime();
			
			System.out.println(TimeUnit.NANOSECONDS.toMillis(stop-start));

			

		}

		public static void main(String[] args) throws IOException {
			PositionAwareFilter filterObj = new PositionAwareFilter();

			String FileName = "data/p1.txt";
			// BufferedReader buf = new BufferedReader(new FileReader(new
			// File("data/p1.txt")));

			filterObj.insertInputFile(FileName);
			System.out.println(filterObj.insertedCount);

			String lookupFile = "data/t1.txt";
			
			filterObj.lookup(lookupFile);
			System.out.println("Success Count is: "+ filterObj.successCount);
			System.out.println("Failure Count is: "+ filterObj.failureCount);
			System.out.println("Lookup Count is: "+filterObj.lookupNum);
			
			for(String i:filterObj.failureList)
				System.out.println(i);
		}
	}



