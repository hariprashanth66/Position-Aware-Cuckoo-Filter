package filter;

public class PosAwareFilterObjects {

	char[] fingerprint;
	 int size;
	 int posSize =5;
	
	public  PosAwareFilterObjects()
	{
		fingerprint = new char[6];
		size =0;
		
		fingerprint[5] = (char)posSize;
	}
}
